<?php
/**
 * 
 */
class Main_model extends CI_Model {
	
	function __construct() {
		parent::__construct();
	}
	
	public function get_categories()
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_categories";
		
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function get_subcategories($value='')
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_subcategories";
		
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function get_sliders($value='')
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_sliders";
		
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function get_high_prods($value='')
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_high_prods";
		
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function get_products($subcat_id, $page)
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_products/$subcat_id/$page";
		//echo $url; exit;
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function get_sub_cat($subcat_id='')
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_sub_cat/$subcat_id";
		//echo $url; exit;
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function get_cities($value='')
	{
		$service = $this->config->item('service');
		
		$url = $service."services/get_cities";
		//echo $url; exit;
		$result = json_decode(file_get_contents($url));
		return $result;
	}
	
	public function register($name, $l_name, $username, $email, $password, $gender, $phone, $zip, $address)
	{
		$data = array(
					 	'FirstName'			=> $name,
					 	'LastName'			=> $l_name,
					 	'username'			=> $username,
					 	'Zip'				=> $zip,
					 	'Phone'				=> $phone,
					 	'Address'			=> $address,
					 	'gender'			=> $gender,
					 	'Password'			=> $password,
					 	'Email'				=> $email,
					 	'RegistrationDate'	=> time()
					 );
		//echo "<pre>";
		//print_r($data); exit;
		$postdata = http_build_query($data);
		$webservices = $this->config->item('service');
		$url = $webservices."services/register";
		//echo $url; exit;
		$res = $this->post_data($url, $postdata);
		//echo $res;
		return $res;
	}
	
	public function login($username, $password)
	{
		$password = sha1($password);
		$webservices = $this->config->item('service');
		$url = $webservices."services/login/$username/$password";
		//echo $url; exit;
		$res = json_decode(file_get_contents($url));
		return $res;
	}
	
	public function get_prod($id)
	{
		$webservices = $this->config->item('service');
		$url = $webservices."services/get_prod/$id";
		//echo $url; exit;
		$res = json_decode(file_get_contents($url));
		return $res;
	}
	
	public function get_items($user_id)
	{
		$webservices = $this->config->item('service');
		$url = $webservices."services/get_items/$user_id";
		//echo $url; exit;
		$res = json_decode(file_get_contents($url));
		return $res;
	}
	
	public function addtocart($user_id, $prod_id, $qty)
	{
		$webservices = $this->config->item('service');
		$url = $webservices."services/addtocart/$user_id/$prod_id/$qty";
		//echo $url; exit;
		$res = json_decode(file_get_contents($url));
		return $res;
	}
	
	public function post_data($url='', $postdata)
	{
		//echo $postdata; exit;
		$opts = array('http' =>
				  	      array(
					          'method'  => 'POST',
					          'header'  => 'Content-type: application/x-www-form-urlencoded',
					          'content' => $postdata
					      )
					  );
		
		$context  = stream_context_create($opts);
		//echo $context; exit;
		$result = json_decode(file_get_contents($url, false, $context));
		return $result;
	}
}
