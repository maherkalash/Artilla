<?php
$lang['jomran'] 		= "Jomran";
$lang['login'] 			= "Login";
$lang['username'] 		= "Username";
$lang['password'] 		= "Password";
$lang['categories'] 	= "Categories ";
$lang['all_categories'] = "All Categories ";
$lang['search'] 		= "Search";
$lang['home'] 			= "Home";
$lang['about_us'] 		= "About Us";
$lang['account'] 		= "Account";
$lang['login'] 			= "Login";
$lang['products'] 		= "Products";
$lang['contact_us'] 	= "Contact Us";
$lang['top_products'] 	= "FEATURED PRODUCTS";
$lang['sale'] 			= "SALE";
$lang['addtocart'] 		= "Add To Cart";
$lang['view'] 			= "View";
$lang['AED'] 			= "AED";
$lang['show'] 			= "Show";
$lang['of'] 			= " of ";
$lang['products'] 		= " Products";
$lang['register'] 		= "Register";
$lang['register_desc'] 	= "By registring you can buy the product you want";
$lang['name'] 			= "First name";
$lang['l_name'] 		= "Last name";
$lang['email'] 			= "Email";
$lang['pass_conf'] 		= "Confirm password";
$lang['choose_gender'] 	= "Choose gender";
$lang['male'] 			= "Male";
$lang['female'] 		= "Female";
$lang['phone'] 			= "Phone";
$lang['address'] 		= "Address";
$lang['zipcode'] 		= "ZIP code";
$lang['avilability'] 	= "Avilability";
$lang['unavailable'] 	= "Unavailable";
$lang['in_stock'] 		= "In Stock";
$lang['brand'] 			= "Brand";
$lang['added_success'] 	= "Added successfully";
$lang['added_s_desc'] 	= "The product was added successfully to your cart";
$lang['added_f_desc'] 	= "Please try to add this later to your cart";
$lang['added_failed'] 	= "Adding failed";
$lang['items'] 			= "Items";
$lang['cart'] 			= "Cart";
$lang['related_prods'] 	= "Related Products";
$lang['wlc'] 			= "Welcome";
$lang['logout'] 		= "Log out";



$lang['email'] 			= "Email";
$lang['sign up'] 		= "Sign up";


