<?php
$lang['jomran'] 		= "جمران";
$lang['login'] 			= "تسجيل الدخول";
$lang['username'] 		= "اسم المستخدم";
$lang['password'] 		= "كلمة المرور";
$lang['categories'] 	= "الأصناف";
$lang['all_categories'] = "جميع الأصناف";
$lang['search'] 		= "بحث";
$lang['home'] 			= "الرئيسية";
$lang['about_us'] 		= "حولنا";
$lang['account'] 		= "حسابي";
$lang['login'] 			= "تسجيل الدخول";
$lang['products'] 		= "المنتجات";
$lang['contact_us'] 	= "اتصل بنا";
$lang['top_products'] 	= "منتجاتنا المميزة";
$lang['sale'] 			= "للبيع";
$lang['addtocart'] 		= "شراء";
$lang['view'] 			= "عرض";
$lang['AED'] 			= "درهم";
$lang['register'] 		= "";
$lang['register_desc'] 	= "";
$lang['sign up'] 		= "تسجيل";




$lang[''] = "";