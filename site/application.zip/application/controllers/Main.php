<?php

/**
 * 
 */
class Main extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		if (!LANG()) {
			$this->session->set_userdata('lang', 'en');
		}
		if(LANG() == 'en') {
			$this->lang->load('main', 'english');
		} else {
			$this->lang->load('main', 'arabic');
		}
		$this->load->model('main_model');
	}
	
	public function index($value='')
	{
		
		$data['main_page'] = 1;
		$data['categories'] = $this->main_model->get_categories();
		$data['subcats']	= $this->main_model->get_subcategories();
		$data['sliders']	= $this->main_model->get_sliders();		
		$data['service']	= $this->config->item('service');
		$data['high_prods']	= $this->main_model->get_high_prods();
		$this->load->view('index', $data);
	}
	
	public function subcat($subcat_id='', $page=0)
	{
		if ($page < 0) {
			redirect(base_url()."sub_cat/$subcat_id/0");
		}
		$prod_details		= $this->main_model->get_products($subcat_id, $page);
		
		$data['products']	= $prod_details->res;
		$data['page_num'] 	= $page_num = $prod_details->page_num;
		if ($page > $page_num) {
			redirect(base_url()."sub_cat/$subcat_id/0");
		}
		$data['items']		= $prod_details->items_num;
		$data['sub_cats']	= $this->main_model->get_sub_cat($subcat_id);
		$data['sub_count']	= count($data['sub_cats']);
		$data['categories'] = $this->main_model->get_categories();
		$data['subcats']	= $this->main_model->get_subcategories();
		$data['sliders']	= $this->main_model->get_sliders();		
		$data['service']	= $this->config->item('service');
		$data['page']		= $page;
		$data['subcat_id']	= $subcat_id;
		$this->load->view('subcat_view', $data);
	}
	
	public function register($value='')
	{
		//exit;
		
		if ($this->session->userdata('user_id')) {
			redirect(base_url());
		}
		if ($_POST) {
			
			$this->form_validation->set_rules('name', trans('name'), 'required');
			$this->form_validation->set_rules('l_name', trans('l_name'), 'required');
			$this->form_validation->set_rules('username', trans('username'), 'required|alpha_numeric');
			$this->form_validation->set_rules('email', trans('email'), 'required|valid_email');
			$this->form_validation->set_rules('password', trans('password'), 'required|alpha_numeric|matches[pass_conf]');
			$this->form_validation->set_rules('pass_conf', trans('pass_conf'), 'required');
			$this->form_validation->set_rules('gender', trans('gender'), 'required');
			$this->form_validation->set_rules('phone', trans('phone'), 'required|numeric');
			$this->form_validation->set_rules('zip', trans('zip_code'), 'required');
			$this->form_validation->set_rules('address', trans('address'), 'required');
			if ($this->form_validation->run()) {
				//echo "string"; exit;
				$name 		= $this->input->post('name');
				$l_name 	= $this->input->post('l_name');
				$username 	= $this->input->post('username');
				$email 		= $this->input->post('email');
				$password 	= $this->input->post('password');
				$gender 	= $this->input->post('gender');
				$phone 		= $this->input->post('phone');
				$zip 		= $this->input->post('zip');
				$address 	= $this->input->post('address');
				$registerd  = $this->main_model->register($name, $l_name, $username, $email, sha1($password), $gender, $phone, $zip, $address);
				if ($registerd) {
					$this->session->set_userdata('username', $username);
					$this->session->set_userdata('password', $password);
					redirect(base_url()."login");
					return;
				}
			}
			//exit;
		}
		//$data['cities'] 	= $this->main_model->get_cities();
		$data['categories'] = $this->main_model->get_categories();
		$data['subcats']	= $this->main_model->get_subcategories();
		$data['sliders']	= $this->main_model->get_sliders();		
		$data['service']	= $this->config->item('service');
		$data['high_prods']	= $this->main_model->get_high_prods();
		$this->load->view('register_view', $data);
	}
	
	public function login()
	{
		if ($this->session->userdata('user_id')) {
			redirect(base_url());
		}
		$username = $this->session->userdata('username');
		$password = $this->session->userdata('password');
		if (!$username && !$password) {
			$this->form_validation->set_rules('username', trans('username'), 'required');
			$this->form_validation->set_rules('password', trans('password'), 'required');
			
			if ($_POST) {
				
				if ($this->form_validation->run()) {
					$username = $this->input->post('username');
					$password = $this->input->post('password');
					//echo $password; exit;
					$res = $this->main_model->login($username, $password);
					if ($res) {
						$this->session->set_userdata('user_id', $res->id);
						$this->session->set_userdata('active', $res->verified);
						$this->session->set_userdata('full_name', $res->f_name.' '.$res->l_name);
					}
				}
				//exit;
			}
		} else {
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('password');
			$res = $this->main_model->login($username, $password);
			if ($res) {
				$this->session->set_userdata('user_id', $res->id);
				$this->session->set_userdata('active', $res->verified);
				$this->session->set_userdata('full_name', $res->f_name.' '.$res->l_name);
			}
		}
		redirect(base_url()."cart_items");
	}
	
	public function logout($value='')
	{
		$this->session->sess_destroy();
		redirect(base_url());
	}
	
	public function cart_prods($value='')
	{
		if (!$this->session->userdata('user_id')) {
			redirect(base_url());
		}
		
		$user_id = $this->session->userdata('user_id');
		
		$data['items']		= $this->main_model->get_items($user_id);
		//echo "<pre>";
		//print_r($data['items']); exit;
		$data['categories'] = $this->main_model->get_categories();
		$data['subcats']	= $this->main_model->get_subcategories();
		$data['sliders']	= $this->main_model->get_sliders();		
		$data['service']	= $this->config->item('service');
		$data['high_prods']	= $this->main_model->get_high_prods();
		$this->load->view('cart_view', $data);
	}
	
	public function addto_cart($prod_id='', $qty='')
	{
		if (!$prod_id || !$qty) {
			echo 0;
			return;
		}
		//echo 1;
		$user_id = $this->session->userdata('user_id');
		$added = $this->main_model->addtocart($user_id, $prod_id, $qty);
		echo $added;
	}
	
	public function product_det($id='')
	{
		$data['prod']		= $prod = $this->main_model->get_prod($id);
		//echo "<pre>"; print_r($prod); exit;
		if (!$prod->prod) {
			redirect(base_url());
		}
		$data['categories'] = $this->main_model->get_categories();
		$data['subcats']	= $this->main_model->get_subcategories();
		$data['sliders']	= $this->main_model->get_sliders();		
		$data['service']	= $this->config->item('service');
		$data['high_prods']	= $this->main_model->get_high_prods();
		$data['prod_id']	= $id;
		$this->load->view('product_view', $data);
	}
}
