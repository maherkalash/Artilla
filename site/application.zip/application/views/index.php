<?php //echo "<pre>"; print_r($high_prods); exit; ?>
<?php $this->load->view('common/header_view') ?>
      
        
        <div class="clearfix"></div>
        <!-- Iview Slider -->
        <div class="slider">
          <div id="iview"> 
      
            	<?php $i = 0; foreach ($sliders as $row): ?>
            		
            		<div data-iview:image="<?php echo $service."uploads/sliders/$row->img" ?>" data-iview:pausetime="6000">
            		</div>	
				<?php $i++; endforeach ?>
                      
              
              
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- end: Header --> 
<!-- Products -->
<div class="row clearfix f-space30"></div>
<div class="container">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 main-column box-block">
      <div class="box-heading"><span><?php echo trans('top_products') ?></span></div>
      <div class="box-content">
        <div class="box-products slide" id="productc1">
          <div class="carousel-inner"> 
            <!-- Items Row -->
            <div class="item active">
              <div class="row box-product"> 
                <!-- Product -->
                <?php foreach ($high_prods as $row): ?>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="margin-top: 20px">
	                  <div class="product-block">
	                    <div class="image">
	                      <div class="product-label product-sale">
	                      	<span><?php echo trans('sale') ?></span>
	                      </div>
	                      <a class="img" href="<?php echo base_url()."product/$row->ProductID" ?>">
	                      	<img alt="product info" src="<?php echo $service."uploads/products/$row->ProductThumb" ?>" title="product title">
	                      </a> 
	                    </div>
	                    <div class="product-meta">
	                      <div class="name">
	                      	<a href="product.html">
	                      		<?php echo LANG() == 'en' ? $row->ProductName_en : $row->ProductName ?>
	                      	</a>
	                      </div>
	                      <div class="big-price"> 
	                      	<span class="price-new">
	                      		<span class="sym"><?php echo trans('AED') ?></span>
	                      		<?php echo $row->ProductPrice - $row->discount ?></span> 
	                      		<?php if ($row->discount > 0): ?>
									<span class="price-old">
		                      			<span class="sym">
		                      				<?php echo trans('AED') ?>
		                      			</span><?php echo $row->ProductPrice ?>
		                      		</span> 
								<?php endif ?>
	                      		
	                      	</div>
	                      <div class="big-btns"> 
	                      	<a class="btn btn-default btn-view pull-left" href="<?php echo base_url()."product/$row->ProductID" ?>">
	                      		<?php echo trans('view') ?>
	                      	</a> 
	                      	<a class="btn btn-default btn-addtocart pull-right" onclick="add()">
	                           <?php echo trans('addtocart') ?>
	                        </a> 
	                      </div>
	                      <div class="small-price"> 
	                      	<span class="price-new">
	                      		<span class="sym">
	                      			<?php echo trans('AED') ?>
	                      		</span>
	                      		<?php echo $row->ProductPrice - $row->discount ?>
	                      	</span> 
	                      	<?php if ($row->discount > 0): ?>
								<span class="price-old">
		                      		<span class="sym"><?php echo trans('AED') ?></span>
		                      		<?php echo $row->ProductPrice ?>
		                      	</span> 
							<?php endif ?>
	                      	
	                      </div>
	                      <div class="rating"> 
	                      	<i class="fa fa-star"></i> 
	                        <i class="fa fa-star"></i> 
	                        <i class="fa fa-star"></i> 
	                        <i class="fa fa-star-half-o"></i> 
	                        <i class="fa fa-star-o"></i> 
	                      </div>
	                      
	                    </div>
	                    <div class="meta-back"></div>
	                  </div>
	                </div>
                <?php endforeach ?>
                
                <!-- end: Product --> 
                
              </div>
            </div>
            <!-- end: Items Row --> 
           
          </div>
        </div>
      </div>
    </div>
  
  </div>
</div>
<div class="row clearfix f-space30"></div>

<!-- Rectangle Banners -->
<div class="row clearfix f-space30"></div>

<!-- end: Rectangle Banners --> 
<!-- Widgets -->

<!-- end: Widgets -->
<div class="row clearfix f-space30"></div>
<?php $this->load->view('common/footer_view'); ?>