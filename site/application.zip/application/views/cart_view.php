
<?php $this->load->view('common/header_view') ?>


<div class="row clearfix f-space10"></div>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="page-title">
        <h2><?php echo trans('cart') ?> (<?php echo $items->count ?> <?php echo trans('items') ?>)</h2>
      </div>
    </div>
  </div>
</div>
<div class="row clearfix f-space10"></div>


<?php foreach ($items->res as $row): ?>
	<div class="container">
	  <div class="row">
	    <div class="product">
	      <div class="col-md-2 col-sm-3 hidden-xs p-wr">
	        <div class="product-attrb-wr">
	          <div class="product-attrb">
	            <div class="image"> 
	            	<a class="img" href="<?php echo base_url()."product/$row->ProductID" ?>">
	            		<img alt="product info" style="height: 100%" src="<?php echo $service."uploads/products/$row->ProductThumb" ?>">
	            	</a> 
	            </div>
	          </div>
	        </div>
	      </div>
	      <div class="col-md-5 col-sm-1  hidden-sm col-xs-9 p-wr">
	        <div class="product-attrb-wr" >
	          <div class="product-meta">
	            <div class="name">
	              <h3><a href="<?php echo base_url()."product/$row->ProductID" ?>"><?php echo LANG() == 'en' ? $row->ProductName_en : $row->ProductName ?></a></h3>
	            </div>
	            <div class="price"> 
	            	<span class="price-new"><span class="sym"><?php echo trans('AED') ?> </span><?php echo $row->ProductPrice - $row->discount ?></span> 
	            	<?php if ($row->discount) { ?>
						<span class="price-old"><span class="sym"><?php echo trans('AED') ?> </span><?php echo $row->ProductPrice ?></span> 
					<?php } ?>
	            </div>
	           
	          </div>
	        </div>
	      </div>
	      
	      <div class="col-md-2 hidden-sm hidden-xs p-wr">
	        <div class="product-attrb-wr">
	          <div class="product-attrb">
	            <div class="qtyinput">
	              <div class="quantity-inp">
	                <input type="text" onchange="change_total(<?php echo $row->ProductPrice - $row->discount ?>)" class="quantity-input" id="qty" name="p_quantity" value="<?php echo $row->OrderAmount ?>">
	                <div class="quantity-txt minusbtn"><a href="#a" onclick="" class="qty qtyminus" ><i class="fa fa-minus fa-fw"></i></a></div>
	                <div class="quantity-txt plusbtn"><a href="#a" class="qty qtyplus" ><i class="fa fa-plus fa-fw"></i></a></div>
	              </div>
	            </div>
	          </div>
	        </div>
	      </div>
	      <div class="col-md-2 hidden-sm hidden-xs p-wr">
	        <div class="product-attrb-wr">
	          <div class="product-attrb">
	            <div class="price"> <span class="t-price"><span class="sym"><?php echo trans('AED') ?> </span>
	            	<span id="total"><?php echo $row->OrderAmount * ($row->ProductPrice - $row->discount) ?></span></span> 
	            </div>
	          </div>
	        </div>
	      </div>
	      <div class="col-md-1 col-sm-2 col-xs-3 p-wr">
	        <div class="product-attrb-wr">
	          <div class="product-attrb">
	            <div class="remove"> <a href="#a" class="color2" data-toggle="tooltip" data-original-title="Remove"><i class="fa fa-trash-o fa-fw color2"></i></a> </div>
	          </div>
	        </div>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- end: product -->
	<div class="row clearfix f-space30"></div>
<?php endforeach ?>
<!-- product -->




<div class="container">
  <div class="row"> 
    
    <!-- 	Total amount -->
    
    <div class="col-md-4 col-sm-4 col-xs-12 cart-box-wr">
      <div class="box-content">
        <div class="cart-box-tm">
          <div class="tm1">Sub-Total</div>
          <div class="tm2">$2167.25</div>
        </div>
        <div class="clearfix f-space10"></div>
        <div class="cart-box-tm">
          <div class="tm1">Eco Tax (-2.00) </div>
          <div class="tm2">$23.60</div>
        </div>
        <div class="clearfix f-space10"></div>
        <div class="cart-box-tm">
          <div class="tm1">VAT (18.2%) </div>
          <div class="tm2">$54.00</div>
        </div>
        <div class="clearfix f-space10"></div>
        <div class="cart-box-tm">
          <div class="tm3 bgcolor2">Total </div>
          <div class="tm4 bgcolor2">$7854.34</div>
        </div>
        <div class="clearfix f-space10"></div>
        <button class="btn large color1 pull-right">Proceed to Checkout</button>
        <div class="clearfix f-space30"></div>
      </div>
    </div>
    
    <!-- end: Total amount --> 
    
  </div>
</div>

<!-- Rectangle Banners -->


</div>
</div>
<div class="row clearfix f-space30"></div>
<!-- footer -->
<?php $this->load->view('common/footer_view') ?>
<script type="text/javascript">
	function change_total(price) {
		alert(1);
		/*qty = document.getElementById("qty").value;
		qty = parseInt(qty);
		price = parseInt(price);
		new_price = qty * price;
		alert(new_price);
		document.getElementById("total").value = new_price;*/
	}
</script>
