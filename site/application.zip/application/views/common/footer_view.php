<!-- footer -->
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-3 col-xs-12 shopinfo">
        <h4 class="title">JOMRAN.COM</h4>
        <p> IS THE LARGEST E-COMMERCE SITE IN THE ARAB 
        	WORLD, FEATURING MORE THAN 10,000 PRODUCTS 
        	ACROSS CATEGORIES SUCH AS CONSUMER 
        	ELECTRONICS, FASHION, HOUSEHOLD GOODS,
        	 WATCHES OR PERFUMES.</p>
        
      </div>
      <div class="col-sm-3 col-xs-12 footermenu">
        <h4 class="title">Information</h4>
        <ul>
          <li class="item"> <a href="#a">Delivery Info</a></li>
          <li class="item"> <a href="#a">FAQs</a></li>
          <li class="item"> <a href="#a">Payment Instructions</a></li>
          <li class="item"> <a href="#a">Request Product</a></li>
          <li class="item"> <a href="#a">Vendor Registration</a></li>
          <li class="item"> <a href="#a">Affiliates</a></li>
          <li class="item"> <a href="#a">Gift Vouchers</a></li>
        </ul>
      </div>
      <div class="col-sm-3 col-xs-12 footermenu">
        <h4 class="title">My account</h4>
        <ul>
          <li class="item"> <a href="#a">My Account</a></li>
          <li class="item"> <a href="#a">Order History</a></li>
          <li class="item"> <a href="#a">Wish List</a></li>
          <li class="item"> <a href="#a">Newsletter</a></li>
        </ul>
      </div>
      <div class="col-sm-3 col-xs-12 getintouch">
        <h4 class="title">get in touch</h4>
        <ul>
          <li>
            <div class="icon"><i class="fa fa-map-marker fa-fw"></i></div>
            <div class="c-info"> <span>JOMRAN , Khalid Bin Al Walid Str Bur Dubai UAE<br>
              <a href='https://www.google.com/maps/dir//25.262375,55.291174/@25.2623416,55.293347,17z/data=!3m1!4b1'>Find us on map</a></span></div>
          </li>
          <li>
            <div class="icon"><i class="fa fa-envelope-o fa-fw"></i></div>
            <div class="c-info"> <span>Email Us At:<br>
              <a href="#a"> info@jomran.com</a></span></div>
          </li>
          <li>
            <div class="icon"><i class="fa fa-phone fa-fw"></i></div>
            <div class="c-info"> <span>Phone :<br>
              <a href="#a">043859985</a></span></div>
          </li>
          <li>
            <div class="icon"> <i class="fa fa-skype fa-fw"></i></div>
            <div class="c-info"> <span>Talk to Us:<br>
              <a href="#a">skypeid</a></span></div>
          </li>
        </ul>
        <div class="social-icons">
          <ul>
            <li class="icon google-plus"><a href="#a"><i class="fa fa-google-plus fa-fw"></i></a></li>
            <li class="icon linkedin"><a href="#a"><i class="fa fa-linkedin fa-fw"></i></a></li>
            <li class="icon twitter"><a href="#a"><i class="fa fa-twitter fa-fw"></i></a></li>
            <li class="icon facebook"><a href='https://www.facebook.com/jomran.online/'><i class="fa fa-facebook fa-fw"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="copyrights">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-8 col-xs-12"> <span class="copytxt">&copy; Copyright 2014 by <a href="#a"> jomranonline</a>  </span> <span class="btmlinks"><a href="#a">Return Policy</a> | <a href="#a">Privacy Policy</a> | <a href="#a">Terms of Use</a></span> </div>
        <div class="col-lg-4 col-sm-4 col-xs-12 payment-icons">  </div>
      </div>
    </div>
  </div>
</footer>
<!-- end: footer --> 

<!-- Style Switcher JS --> 
<script src="<?php echo base_url(); ?>assets/js/style-switch.js" type="text/javascript"></script>

<script>

(function($) {
  "use strict";
 $('#menuMega').menu3d();
                $('#iview').iView({
                    pauseTime: 10000,
                    pauseOnHover: true,
                    directionNavHoverOpacity: 0.6,
                    timer: "360Bar",
                    timerBg: '#2da5da',
                    timerColor: '#fff',
                    timerOpacity: 0.9,
                    timerDiameter: 20,
                    timerPadding: 1,
					touchNav: true,
                    timerStroke: 2,
                    timerBarStrokeColor: '#fff'
                });
				
                $('.quickbox').carousel({
                    interval: 10000
                });
               $('#monthly-deals').carousel({
                    interval: 3000
                });
                $('#productc2').carousel({
                    interval: 4000
                });
                $('#tweets').carousel({
                    interval: 5000
                });
})(jQuery);


          
        </script>
</body>
</html> 
