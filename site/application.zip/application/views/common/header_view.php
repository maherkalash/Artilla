<?php //echo "<pre>";
//print_r($subcats); exit;
 ?>
<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7 lte9 lte8 lte7" lang="en-US"><![endif]-->
<!--[if IE 8]><html class="ie ie8 lte9 lte8" lang="en-US">	<![endif]-->
<!--[if IE 9]><html class="ie ie9 lte9" lang="en-US"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="noIE" lang="en-US">
<!--<![endif]-->

<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<meta content="<?php echo trans('jomran') ?>" name="description">
<meta content="logoby.us" name="author">
<link href="images/ico.png" rel="shortcut icon">
<title><?php echo trans('jomran'); ?></title>

<!-- Reset CSS -->
<link href="<?php echo base_url(); ?>assets/css/normalize.css" rel="stylesheet" type="text/css"/>

<!-- Bootstrap core CSS -->
<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet">
<?php if (LANG() != 'en') { ?>
	<link href="<?php echo base_url(); ?>assets/css/bootstrap-rtl.css" rel="stylesheet" type="text/css" />
<?php } ?>

<!-- Iview Slider CSS -->
<link href="<?php echo base_url(); ?>assets/css/iview.css" rel="stylesheet">

<!--	Responsive 3D Menu	-->
<link href="<?php echo base_url(); ?>assets/css/menu3d.css" rel="stylesheet"/>

<!-- Animations -->
<link href="<?php echo base_url(); ?>assets/css/animate.css" rel="stylesheet" type="text/css"/>

<!-- Custom styles for this template -->
<link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css">
<!-- Style Switcher -->


<!-- Color -->
<link href="<?php echo base_url(); ?>assets/css/skin/color.css" id="colorstyle" rel="stylesheet">
<?php if (LANG() != 'en') { ?>
	<link href="<?php echo base_url(); ?>assets/css/rtl.css" rel="stylesheet" type="text/css" />
<?php } ?>



<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]> <script src="js/html5shiv.js"></script> <script src="js/respond.min.js"></script> <![endif]-->

<!-- Bootstrap core JavaScript -->
<script src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-select.js"></script>

<!-- Custom Scripts -->
<script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>

<!-- MegaMenu -->
<script src="<?php echo base_url(); ?>assets/js/menu3d.js" type="text/javascript"></script>

<!-- iView Slider -->
<script src="<?php echo base_url(); ?>assets/js/raphael-min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.easing.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/iview.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/retina-1.1.0.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/sweetalert.css">
<script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>

<!--[if IE 8]>
    <script type="text/javascript" src="js/selectivizr.js"></script>
    <![endif]-->

</head>

<body>
<!-- Header -->
<header> 
  <!-- Top Heading Bar -->
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="topheadrow">
          <ul class="nav nav-pills pull-right">
          	<?php if (!$this->session->userdata('user_id')): ?>
				  <li class="dropdown"> <a class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown" href="#a"> <i class="fa fa-user fa-fw"></i> <span class="hidden-xs"> <?php echo trans('login') ?></span></a>
		              <div class="loginbox dropdown-menu"> <span class="form-header"><?php echo trans('login') ?></span> 
		                <form method="post" action="<?php echo base_url()."login" ?>">
		                  <div class="form-group"> <i class="fa fa-user fa-fw"></i>
		                    <input class="form-control" name="username" id="InputUserName" placeholder="<?php echo trans('username') ?>" type="text" data-validation="required">
		                  </div>
		                  <div class="form-group"> <i class="fa fa-lock fa-fw"></i>
		                    <input class="form-control" id="InputPassword" name="password" placeholder="<?php echo trans('password') ?>" type="password" data-validation="required">
		                  </div>
		                  <button class="btn medium color1 pull-right" type="submit"><?php echo trans('login') ?></button>
		                </form>
		                <button class="btn medium color1 pull-right" onclick="location.href = '<?php echo base_url() ?>register'"; ><?php echo trans('sign up') ?></button>
		              </div>
		            </li>
			  <?php else: ?>
			  	<li> 
			  		<a class="dropdown-toggle" href="<?php echo base_url()."cart_items" ?>"> <i class="fa fa-user fa-fw"></i> 
			  			<span class="hidden-xs"> <?php echo trans('wlc').' '.$this->session->userdata('full_name'); ?></span>
			  		</a>
			  	</li>
			  	<li> 
			  		<a class="dropdown-toggle" href="<?php echo base_url()."logout" ?>"> <i class="fa fa-power-off fa-fw"></i> 
			  			<span class="hidden-xs"> <?php echo trans('logout'); ?></span>
			  		</a>
			  	</li>
			  <?php endif ?>
            
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- end: Top Heading Bar -->
  
  <div class="f-space20"></div>
  <!-- Logo and Search -->
  <div class="container">
    <div class="row clearfix">
      <div class="col-lg-3 col-xs-12">
        <div class="logo"> <a href="http://jomran.com/site" title="<?php echo trans('jomran') ?>"><!-- <img alt="Flatro - Responsive Metro Inspired Flat ECommerce theme" src="images/logo2.png"> -->
          <div class="logoimage"><img src="<?php echo base_url() ?>assets/images/logo.png" /></div>
          <div class="logotext"><span><strong><?php echo trans('jomran') ?></strong></span></div>
          <span class="slogan"></span></a> </div>
      </div>
      <!-- end: logo -->
      <div class="visible-xs f-space20"></div>
      <!-- search -->
      <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12 pull-right">
        <div class="searchbar">
          <form action="#">
            <ul class="pull-left">
              <li class="input-prepend dropdown" data-select="true"> 
              	<a class="add-on dropdown-toggle" data-hover="dropdown" data-toggle="dropdown" href="#a"> 
              	  <span class="dropdown-display">
	              	<?php echo trans('all_categories') ?>
	              </span> <i class="fa fa-sort fa-fw"></i>
	            </a> 
                <!-- this hidden field is used to contain the selected option from the dropdown -->
                <input class="dropdown-field" type="hidden" value="All Categories"/>
                <ul class="dropdown-menu" role="menu">
                  <?php foreach ($categories as $cat): ?>
                      <li>
                      	<a href="#a" data-value="Men Wear">
                      	  <?php echo LANG() == 'en' ? $cat->CategoryName_en : $cat->CategoryName ?>
                      	</a>
                      </li>
                  <?php endforeach ?>
                  <li><a href="#a" data-value="All Categories"><?php echo trans('all_categories') ?></a></li>
                </ul>
              </li>
            </ul>
            <div class="searchbox pull-left">
              <input class="searchinput" id="search" placeholder="<?php echo trans('search') ?>..." type="search">
              <button class="fa fa-search fa-fw" type="submit"></button>
            </div>
          </form>
        </div>
      </div>
      <!-- end: search --> 
      
    </div>
  </div>
  <!-- end: Logo and Search -->
  <div class="f-space20"></div>
  <!-- Menu -->
  <div class="container">
    <div class="row clearfix">
      <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 menu-col">
        <div class="<?php echo isset($main_page) ? 'menu-heading' : 'menu-heading menuHeadingdropdown' ?>"> <span> <i class="fa fa-bars"></i> <?php echo trans('categories') ?></span> </div>
        <!-- Mega Menu -->
        <div class="<?php echo isset($main_page) ? 'menu3dmega vertical' : 'menu3dmega vertical menuMegasub' ?>" id="menuMega">
          <ul>
            <!-- Menu Item Links for Mobiles Only -->
            <li class="visible-xs"> <a href="<?php echo base_url() ?>"> <i class="fa fa-home"></i> <span><?php echo trans('home') ?></span> <i class="fa fa-angle-right"></i> </a>
              <div class="dropdown-menu flyout-menu"> 
                <!-- Sub Menu -->
                <ul>
                  <li><a href="about.html"><?php echo trans('about_us') ?></a></li>
                  <li> <a href="#a"><span><?php echo trans('account') ?></span> <i class="fa fa-caret-right"></i> </a>
                    <ul class="dropdown-menu sub flyout-menu">
                      <li><a href="#a"><?php echo trans('login') ?></a></li>
                    </ul>
                  </li>
                  <li> 
                  	<a href="#a"><span><?php echo trans('products') ?></span> <i class="fa fa-caret-right"></i> </a>
                  </li>
                  <li><a href="contact.html"><?php echo trans('contact_us') ?></a></li>
                </ul>
                <!-- end: Sub Menu --> 
              </div>
            </li>
            <!-- end: Menu Item --> 
            <!-- Menu Item -->
            
			
			<?php $i = 0; foreach ($subcats as $row) { ?>
				<?php if ($i == 0 || $row->CategoryID != $subcats[$i - 1]->CategoryID) { ?>
					<li> <a href="#a"> <i class=""></i> <span> <?php echo LANG() == 'en' ? $row->CategoryName_en : $row->CategoryName ?></span> <i class="fa fa-angle-right"></i> </a>
		              <div class="dropdown-menu"> 
		                <!-- Sub Menu -->
		                <div class="content">
		                  <div class="row">
		                    <div class="col-md-5">
		                      <ul>
				<?php } ?>
					<li><a class="menu-title" href="<?php echo base_url()."sub_cat/$row->ID" ?>"><?php echo LANG() == 'en' ? $row->SubCategoryName_en : $row->SubCategoryName ?></a></li>
				<?php if (!isset($subcats[$i + 1]) || ($row->CategoryID != $subcats[$i + 1]->CategoryID)) { ?>
							 </ul>
							  
	                      </a> 
		                    </div>
		                    
		                  </div>
		                </div>
		                <!-- end: Sub Menu --> 
		              </div>
		            </li>
				<?php } ?>
			<?php $i++; } ?>
            
            <!-- end: Menu Item --> 
            
            <!-- end: Menu Item -->
          </ul>
        </div>
        <!-- end: Mega Menu --> 
      </div>
      <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12 menu-col-2"> 
        <!-- Navigation Buttons/Quick Cart for Tablets and Desktop Only -->
        <div class="menu-links hidden-xs">
          <ul class="nav nav-pills nav-justified">
            <li> <a href="http://jomran.com/site"> <i class="fa fa-home fa-fw"></i> <span class="hidden-sm"><?php echo trans('home') ?></span></a> </li>
            <li> <a href="about.html"> <i class="fa fa-info-circle fa-fw"></i> <span class="hidden-sm"><?php echo trans('about_us') ?></span></a> </li>
            <li> <a href="blog.html"> <i class="fa fa-bullhorn fa-fw"></i> <span class="hidden-sm"><?php echo trans('account') ?></span></a> </li>
            <li> <a href="contact.html"> <i class="fa fa-pencil-square-o fa-fw"></i> <span class="hidden-sm "><?php echo trans('contact_us') ?></span></a> </li>
              
            </li>
          </ul>
        </div>
        <!-- end: Navigation Buttons/Quick Cart Tablets and large screens Only --> 
        <?php if (!isset($main_page)): ?>
             </div>
        <?php endif ?>
       